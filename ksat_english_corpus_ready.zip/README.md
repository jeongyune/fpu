# Korean High School English Reading Corpus

개인용 Streamlit 앱입니다.

기능:
- PDF 업로드
- PDF 텍스트 추출 (PyMuPDF)
- 듣기 문항(기본적으로 1~17번) 제외
- 18번 이후 문항을 자동 분리
- 문항 유형 자동 추정
- 주제/세부주제 태그 지정 및 수정
- 검색/필터
- CSV 다운로드
- 현재 데이터 CSV 업로드/복원

## 실행

```bash
pip install -r requirements.txt
streamlit run app.py
```

GitHub Codespaces에서도 같은 명령으로 실행할 수 있습니다.

## 주의
초기 버전은 텍스트 레이어가 있는 PDF를 기준으로 합니다.
스캔 이미지 PDF는 OCR 단계가 별도로 필요합니다.

기출 지문 원문을 외부에 공개 배포하기보다는 개인 연구/학습용으로 사용하는 것을 권장합니다.
